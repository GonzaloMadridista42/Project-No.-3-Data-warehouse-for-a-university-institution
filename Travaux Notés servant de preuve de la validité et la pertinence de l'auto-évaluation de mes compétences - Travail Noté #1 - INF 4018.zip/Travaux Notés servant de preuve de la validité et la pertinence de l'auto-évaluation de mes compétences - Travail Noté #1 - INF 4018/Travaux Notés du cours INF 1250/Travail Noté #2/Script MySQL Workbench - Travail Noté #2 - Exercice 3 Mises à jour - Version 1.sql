USE projet_jegere;

UPDATE projet
SET IDResponsable=1212
WHERE IDResponsable=1876