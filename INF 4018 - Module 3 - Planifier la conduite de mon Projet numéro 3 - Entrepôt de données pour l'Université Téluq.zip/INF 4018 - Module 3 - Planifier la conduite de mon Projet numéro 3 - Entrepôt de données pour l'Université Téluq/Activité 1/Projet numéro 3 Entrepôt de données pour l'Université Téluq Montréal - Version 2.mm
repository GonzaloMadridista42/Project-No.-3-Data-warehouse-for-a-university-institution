<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#660000" CREATED="1666037030348" ID="ID_526938244" MODIFIED="1666037579368" TEXT="Projet num&#xe9;ro 3: Entrep&#xf4;t de donn&#xe9;es pour l&apos;Universit&#xe9; T&#xe9;luq Montr&#xe9;al.">
<node COLOR="#0033ff" CREATED="1666037250492" ID="ID_308699456" MODIFIED="1666205850545" POSITION="right" TEXT="M&#xe9;thode d&apos;Analyse et Conception Orient&#xe9;e Objet RUP (&#xc9;cheancier).">
<icon BUILTIN="bookmark"/>
<node COLOR="#006633" CREATED="1666037348323" ID="ID_587091058" MODIFIED="1666206171098" TEXT="Phase d&apos;Inception.">
<icon BUILTIN="yes"/>
<node CREATED="1666202136798" ID="ID_1961412915" MODIFIED="1666204236937" TEXT="&#xc9;tude d&apos;opportunit&#xe9;.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202485176" ID="ID_1467598609" MODIFIED="1666202778090" TEXT="&#xc9;cheancier.">
<node CREATED="1666202705242" ID="ID_1169846060" MODIFIED="1666202837746" TEXT=" 10/10/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666202160429" ID="ID_381266783" MODIFIED="1666204241317" TEXT="&#xc9;tude de faissabilit&#xe9;.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202744042" ID="ID_306110452" MODIFIED="1666202748463" TEXT="&#xc9;cheancier.">
<node CREATED="1666202756011" ID="ID_344209815" MODIFIED="1666202844467" TEXT=" 10/10/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node COLOR="#006600" CREATED="1666037350342" ID="ID_614698704" MODIFIED="1666206189548" TEXT="Phase d&apos;&#xc9;laboration.">
<icon BUILTIN="yes"/>
<node CREATED="1666202908430" ID="ID_1140683692" MODIFIED="1666204245275" TEXT="D&#xe9;terminer les exigences du Projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666203019809" ID="ID_93915153" MODIFIED="1666203026750" TEXT="&#xc9;cheancier.">
<node CREATED="1666203032774" ID="ID_1660003362" MODIFIED="1666203097218" TEXT=" 10/12/22 ">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666202956179" ID="ID_1103873252" MODIFIED="1666204249669" TEXT="D&#xe9;terminer les contraintes du Projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202983910" ID="ID_515893734" MODIFIED="1666202987966" TEXT="&#xc9;cheancier.">
<node CREATED="1666203037904" ID="ID_964623688" MODIFIED="1666203057410" TEXT=" 10/12/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node COLOR="#006600" CREATED="1666037352210" ID="ID_829027491" MODIFIED="1666204218526" TEXT="Phase de construction.">
<arrowlink DESTINATION="ID_829027491" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_1737885890" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_829027491" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_1737885890" SOURCE="ID_829027491" STARTARROW="None" STARTINCLINATION="0;0;"/>
<icon BUILTIN="yes"/>
<node CREATED="1666203342299" ID="ID_935130947" MODIFIED="1666204254090" TEXT="Analyse globale et d&#xe9;taill&#xe9;e du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204414766" ID="ID_52834490" MODIFIED="1666204610453" TEXT="&#xc9;cheancier.">
<node CREATED="1666204816299" ID="ID_660833319" MODIFIED="1666205671748" TEXT=" 9/24/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666203343686" ID="ID_1871417245" MODIFIED="1666204258560" TEXT="Analyse exhaustive et compl&#xe8;te du projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204417430" ID="ID_1653269044" MODIFIED="1666204608214" TEXT="&#xc9;cheancier.">
<node CREATED="1666204829396" ID="ID_1192232870" MODIFIED="1666205675853" TEXT=" 9/24/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666203345577" ID="ID_539713604" MODIFIED="1666205693000" TEXT="Recherches sur Google et Yahoo, de noms et noms de familles fictifs des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204419672" ID="ID_1208411214" MODIFIED="1666204920727" TEXT="&#xc9;cheancier.">
<node CREATED="1666204912216" ID="ID_68062554" MODIFIED="1666205701608" TEXT=" 9/28/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666203347115" ID="ID_970785167" MODIFIED="1666204266252" TEXT="Conception et cr&#xe9;ation du diagramme de cas d&apos;utilisation, pour le projet num&#xe9;ro 3. ">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204421749" ID="ID_1059340703" MODIFIED="1666204602896" TEXT="&#xc9;cheancier.">
<node CREATED="1666204960457" ID="ID_1356638852" MODIFIED="1666205710914" TEXT=" 10/17/22">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1666203349551" ID="ID_1688652690" MODIFIED="1666204269870" TEXT="Conception d&#xe9;taill&#xe9;e des trois cubes de donn&#xe9;es du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204424091" ID="ID_833226387" MODIFIED="1666204599622" TEXT="&#xc9;cheancier.">
<node CREATED="1666205028077" ID="ID_252868979" MODIFIED="1666210054528" TEXT=" 11/20/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1675281900312"/>
</hook>
</node>
</node>
</node>
<node CREATED="1666203351329" ID="ID_1634988911" MODIFIED="1666204295759" TEXT="D&#xe9;veloppement d&#xe9;taill&#xe9; des trois cubes de donn&#xe9;es du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204426158" ID="ID_1979674590" MODIFIED="1666204597018" TEXT="&#xc9;cheancier.">
<node CREATED="1666205057059" ID="ID_1064072440" MODIFIED="1666210066210" TEXT=" 01/23/23">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1675281900312"/>
</hook>
</node>
</node>
</node>
<node CREATED="1666203352941" ID="ID_744282713" MODIFIED="1666206481265" TEXT="Mise en oeuvre des trois cubes de donn&#xe9;es d&#xe9;velopp&#xe9;es.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204428218" ID="ID_1412910865" MODIFIED="1666204584955" TEXT="&#xc9;cheancier.">
<node CREATED="1666205089503" ID="ID_692096195" MODIFIED="1666206950177" TEXT=" 2/1/23">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1675281900312"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666211315478" ID="ID_909069369" MODIFIED="1666211625272" POSITION="left" TEXT="Lisdte de documents pour mod&#xe9;liser les trois cubes de donn&#xe9;es du projet num&#xe9;ro 3.">
<node CREATED="1666211645207" ID="ID_1685324939" MODIFIED="1666212588985" TEXT="Documents pour mod&#xe9;lisation d&apos;un entrep&#xf4;t de donn&#xe9;es.">
<node CREATED="1666212592763" ID="ID_1018327723" LINK="Lien%201%20-%20Mod&#xe9;liser%20un%20entrep&#xf4;t%20de%20donn&#xe9;es.html" MODIFIED="1666212604672" TEXT=""/>
<node CREATED="1666212596056" ID="ID_1773280317" LINK="Lien%202%20-%20Mod&#xe9;liser%20un%20entrep&#xf4;t%20de%20donn&#xe9;es.html" MODIFIED="1666212611523" TEXT=""/>
</node>
<node CREATED="1666211647276" ID="ID_559688181" MODIFIED="1666211907361" TEXT="Documents sur le mod&#xe8;le d&apos;entrep&#xf4;t de donn&#xe9;es sous forme d&apos;&#xe9;toile.">
<node CREATED="1666212617018" ID="ID_1262088620" LINK="Mod&#xe8;le%20d&apos;entrep&#xf4;t%20de%20donn&#xe9;es%20sous%20forme%20d&apos;&#xe9;toile.pdf" MODIFIED="1666212634281" TEXT=""/>
</node>
<node CREATED="1666211649912" ID="ID_846999370" MODIFIED="1666211872600" TEXT="Documents sur la mod&#xe9;lisation de cubes de donn&#xe9;es d&apos;un entrep&#xf4;t de donn&#xe9;es.">
<node CREATED="1666212619616" ID="ID_1334322813" LINK="Lien%201%20-%20Mod&#xe9;liser%20des%20cubes%20de%20donn&#xe9;es%20d&apos;un%20entrep&#xf4;t%20de%20donn&#xe9;es.html" MODIFIED="1666212648668" TEXT=""/>
</node>
</node>
<node CREATED="1666037491913" ID="ID_1801881356" MODIFIED="1666211255026" POSITION="left" TEXT="Liste de documents pour la r&#xe9;alisation du projet num&#xe9;ro 3.">
<icon BUILTIN="desktop_new"/>
<node CREATED="1666201887556" ID="ID_329701624" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~3/LISTED~2.DOC" MODIFIED="1666203880826" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201896469" ID="ID_1887368380" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~3/LISTED~1.DOC" MODIFIED="1666203893523" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201898539" ID="ID_1343360142" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~3/MODULE~1.XLS" MODIFIED="1666203898668" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201900313" ID="ID_1590859968" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~3/MODULE~2.XLS" MODIFIED="1666203905252" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201902069" ID="ID_983993807" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~2/IN5ADC~1.DOC" MODIFIED="1666203926753" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201903755" ID="ID_1961724932" LINK="INF4018-Projet-3-v1.pdf" MODIFIED="1666203933858" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201905415" ID="ID_938183151" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~1/LISTED~1.DOC" MODIFIED="1666203939092" TEXT="">
<icon BUILTIN="folder"/>
</node>
<node CREATED="1666201907423" ID="ID_148341517" LINK="../../../../../GONZAL~1/DOCUME~1/COURST~2/INF401~1/INF401~1/DI89DD~1.MDJ" MODIFIED="1666203943631" TEXT="">
<icon BUILTIN="folder"/>
</node>
</node>
<node CREATED="1666205732797" ID="ID_1416792251" MODIFIED="1666205869839" POSITION="right" TEXT="M&#xe9;thode d&apos;Analyse et Conception Orient&#xe9;e Objet RUP (Livrables).">
<node CREATED="1666206110488" ID="ID_248936788" MODIFIED="1666206183681" TEXT="Phase d&apos;Inception.">
<node CREATED="1666206385733" ID="ID_1305904005" MODIFIED="1666206385733" TEXT="">
<node CREATED="1666202136798" ID="ID_1052830629" MODIFIED="1666204236937" TEXT="&#xc9;tude d&apos;opportunit&#xe9;.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202485176" ID="ID_913864724" MODIFIED="1666207015341" TEXT="Livrables.">
<node CREATED="1666207295954" ID="ID_1814060419" MODIFIED="1666207478240" TEXT="Document Word de l&apos;&#xe9;tude d&apos;opportunit&#xe9;.">
<node CREATED="1666202705242" ID="ID_1779921020" MODIFIED="1666211697595" TEXT="  10/24/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206387937" ID="ID_612593357" MODIFIED="1666206387937" TEXT="">
<node CREATED="1666202160429" ID="ID_46377671" MODIFIED="1666204241317" TEXT="&#xc9;tude de faissabilit&#xe9;.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202744042" ID="ID_1827689460" MODIFIED="1666207393907" TEXT="Livrables.">
<node CREATED="1666207404250" ID="ID_391588052" MODIFIED="1666207465092" TEXT="Document Word de l&apos;&#xe9;tude de faissabilit&#xe9;.">
<node CREATED="1666202756011" ID="ID_1634551748" MODIFIED="1666211701253" TEXT="  10/24/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206116231" ID="ID_1271853894" MODIFIED="1666206196463" TEXT="Phase d&apos;&#xc9;laboration.">
<node CREATED="1666206391813" ID="ID_1680441245" MODIFIED="1666206391813" TEXT="">
<node CREATED="1666202908430" ID="ID_1516517090" MODIFIED="1666204245275" TEXT="D&#xe9;terminer les exigences du Projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666203019809" ID="ID_110587654" MODIFIED="1666207706268" TEXT="Livrables.">
<node CREATED="1666207712933" ID="ID_645305410" MODIFIED="1666207854311" TEXT="Document Word des exigences du projet num&#xe9;ro 3.">
<node CREATED="1666207761012" ID="ID_265838176" MODIFIED="1666211704864" TEXT="  10/24/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206393383" ID="ID_1996997631" MODIFIED="1666206393383" TEXT="">
<node CREATED="1666202956179" ID="ID_885514250" MODIFIED="1666204249669" TEXT="D&#xe9;terminer les contraintes du Projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666202983910" ID="ID_1772336841" MODIFIED="1666207677876" TEXT="Livrables.">
<node CREATED="1666207852312" ID="ID_21011907" MODIFIED="1666207873843" TEXT="Document Word des contraintes du projet num&#xe9;ro 3.">
<node CREATED="1666207882485" ID="ID_962251026" MODIFIED="1666211709249" TEXT="  10/24/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206162063" ID="ID_1040605910" MODIFIED="1666206206267" TEXT="Phase de construction.">
<node CREATED="1666206395261" ID="ID_274712436" MODIFIED="1666206395261" TEXT="">
<node CREATED="1666203342299" ID="ID_1824101815" MODIFIED="1666204254090" TEXT="Analyse globale et d&#xe9;taill&#xe9;e du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204414766" ID="ID_1627891369" MODIFIED="1666206667536" TEXT="Livrables.">
<node CREATED="1666207896291" ID="ID_1307435843" MODIFIED="1666207951297" TEXT="Document Word de l&apos;analyse globale et d&#xe9;taill&#xe9;e duprojet num&#xe9;ro 3.">
<node CREATED="1666207948015" ID="ID_680337347" MODIFIED="1666211712694" TEXT=" 10/28/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206396772" ID="ID_1536802787" MODIFIED="1666206396772" TEXT="">
<node CREATED="1666203343686" ID="ID_332771866" MODIFIED="1666204258560" TEXT="Analyse exhaustive et compl&#xe8;te du projet num&#xe9;ro 3">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204417430" ID="ID_1411173403" MODIFIED="1666206677888" TEXT="Livrables.">
<node CREATED="1666207898584" ID="ID_148838598" MODIFIED="1666208480282" TEXT="Document Word de l&apos;analyse exhaustive et compl&#xe8;te du projet num&#xe9;ro 3.">
<node CREATED="1666208493557" ID="ID_1340694641" MODIFIED="1666211718319" TEXT=" 10/28/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206398023" ID="ID_664158538" MODIFIED="1666206398023" TEXT="">
<node CREATED="1666203345577" ID="ID_456403719" MODIFIED="1666205693000" TEXT="Recherches sur Google et Yahoo, de noms et noms de familles fictifs des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204419672" ID="ID_1701767482" MODIFIED="1666206686663" TEXT="Livrables.">
<node CREATED="1666207901022" ID="ID_1545797017" MODIFIED="1666208732335" TEXT="Liste de pages web affichant des listes de nom et de noms de familla de personnes de diverses origines.">
<node CREATED="1666208749631" ID="ID_377176203" MODIFIED="1666211722229" TEXT=" 10/28/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206399223" ID="ID_1354177559" MODIFIED="1666206399223" TEXT="">
<node CREATED="1666203347115" ID="ID_420554217" MODIFIED="1666204266252" TEXT="Conception et cr&#xe9;ation du diagramme de cas d&apos;utilisation, pour le projet num&#xe9;ro 3. ">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204421749" ID="ID_595358040" MODIFIED="1666206691658" TEXT="Livrables.">
<node CREATED="1666207902761" ID="ID_1217952803" MODIFIED="1666208822983" TEXT="Mod&#xe8;le de Cas d&apos;Utilisation compl&#xe8;te du syst&#xe8;me d&apos;affichage des notes des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<node CREATED="1666208819232" ID="ID_865361533" MODIFIED="1666211727098" TEXT=" 10/30/22">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206400382" ID="ID_974132885" MODIFIED="1666206400382" TEXT="">
<node CREATED="1666203349551" ID="ID_205117282" MODIFIED="1666204269870" TEXT="Conception d&#xe9;taill&#xe9;e des trois cubes de donn&#xe9;es du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204424091" ID="ID_1673247389" MODIFIED="1666206696862" TEXT="Livrables.">
<node CREATED="1666207904434" ID="ID_1552298045" MODIFIED="1666209179787" TEXT="Fichier Excel, contenant la liste compl&#xe8;te de tous les &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq, ainsi que le fichier Excel des trois sch&#xe9;mas en &#xe9;toile, des trois cubes de donn&#xe9;es du syst&#xe8;me d&apos;affichage des notes des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<node CREATED="1666208949874" ID="ID_1330707751" MODIFIED="1666211730970" TEXT="01/30/23">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206401426" ID="ID_1832223286" MODIFIED="1666206401426" TEXT="">
<node CREATED="1666203351329" ID="ID_362021683" MODIFIED="1666204295759" TEXT="D&#xe9;veloppement d&#xe9;taill&#xe9; des trois cubes de donn&#xe9;es du projet num&#xe9;ro 3.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204426158" ID="ID_1333035386" MODIFIED="1666206702015" TEXT="Livrables.">
<node CREATED="1666207906322" ID="ID_1850238490" MODIFIED="1666209083274" TEXT="Fichier Excel, contenant les trois sch&#xe9;mas en &#xe9;toile, des trois cubes de donn&#xe9;es du syst&#xe8;me d&apos;affichage des notes des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<node CREATED="1666209183625" ID="ID_396438379" MODIFIED="1666211735268" TEXT="01/30/23">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666206402744" ID="ID_1922859716" MODIFIED="1666206402744" TEXT="">
<node CREATED="1666203352941" ID="ID_19540732" MODIFIED="1666206483868" TEXT="Mise en oeuvre des trois cubes de donn&#xe9;es d&#xe9;velopp&#xe9;es.">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1666204428218" ID="ID_1809142859" MODIFIED="1666206706895" TEXT="Livrables.">
<node CREATED="1666207908006" ID="ID_617289211" MODIFIED="1666209411646" TEXT="Le fichier d&apos;extension .sql des trois cubes de donn&#xe9;es, avec ses sch&#xe9;mas de cubes de donn&#xe9;es, du syst&#xe8;me d&apos;affichage des notes des &#xe9;tudiants de l&apos;Universit&#xe9; T&#xe9;luq.">
<node CREATED="1666209414596" ID="ID_1486489693" MODIFIED="1666211739542" TEXT=" 2/07/23">
<icon BUILTIN="go"/>
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1672436040201"/>
</hook>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1666205753096" ID="ID_73641626" MODIFIED="1666205894399" POSITION="left" TEXT="Pr&#xe9;sentation globale du projet num&#xe9;ro 3.">
<node CREATED="1666205954708" ID="ID_1714666345" MODIFIED="1666206060666" TEXT="Pr&#xe9;sentation du projet num&#xe9;ro 3.">
<icon BUILTIN="folder"/>
<node CREATED="1666206002166" ID="ID_299074395" LINK="INF4018-Projet-3-v1.pdf" MODIFIED="1666206026411" TEXT=""/>
</node>
<node CREATED="1666205957121" ID="ID_305693036" MODIFIED="1666206077532" TEXT="Objjectifs du projet num&#xe9;ro 3.">
<arrowlink DESTINATION="ID_305693036" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_226878783" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_305693036" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_226878783" SOURCE="ID_305693036" STARTARROW="None" STARTINCLINATION="0;0;"/>
<icon BUILTIN="folder"/>
<node CREATED="1666206017543" ID="ID_708610462" LINK="INF4018-Projet-3-v1.pdf" MODIFIED="1666206035709" TEXT=""/>
</node>
</node>
</node>
</map>
