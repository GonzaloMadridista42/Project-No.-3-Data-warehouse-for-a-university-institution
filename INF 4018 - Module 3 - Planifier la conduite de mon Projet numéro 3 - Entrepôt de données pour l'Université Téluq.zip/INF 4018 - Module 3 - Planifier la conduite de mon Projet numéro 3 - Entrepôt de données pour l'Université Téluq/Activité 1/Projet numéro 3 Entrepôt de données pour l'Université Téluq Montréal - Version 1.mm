<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#660000" CREATED="1666037030348" ID="ID_526938244" MODIFIED="1666037579368" TEXT="Projet num&#xe9;ro 3: Entrep&#xf4;t de donn&#xe9;es pour l&apos;Universit&#xe9; T&#xe9;luq Montr&#xe9;al.">
<node COLOR="#0033ff" CREATED="1666037250492" ID="ID_308699456" MODIFIED="1666037415931" POSITION="right" TEXT="M&#xe9;thode d&apos;Analyse et Conception Orient&#xe9;e Objet RUP">
<node COLOR="#006633" CREATED="1666037348323" ID="ID_587091058" MODIFIED="1666037429257" TEXT="Phase d&apos;Inception."/>
<node COLOR="#006600" CREATED="1666037350342" ID="ID_614698704" MODIFIED="1666037439207" TEXT="Phase d&apos;&#xc9;laboration."/>
<node COLOR="#006600" CREATED="1666037352210" ID="ID_829027491" MODIFIED="1666037446312" TEXT="Phase de construction."/>
</node>
<node CREATED="1666037491913" ID="ID_1801881356" MODIFIED="1666037570211" POSITION="left" TEXT="Liste de documents pour la r&#xe9;alisation du projet num&#xe9;ro 3."/>
</node>
</map>
