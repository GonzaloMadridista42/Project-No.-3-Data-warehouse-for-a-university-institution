<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1666034115598" ID="ID_1244138890" MODIFIED="1666034536246" TEXT="Projet_Intranet.">
<node COLOR="#ff0000" CREATED="1666034459313" ID="ID_1734155028" MODIFIED="1666034879066" POSITION="left" TEXT="&#xc9;tapes du Projet.">
<icon BUILTIN="bookmark"/>
<node CREATED="1666035488172" ID="ID_626422659" MODIFIED="1666035833477" TEXT="Planifier.">
<node CREATED="1666035553504" ID="ID_1300940695" MODIFIED="1666036149671" TEXT="Analyse des besoins. 11/15/15">
<hook NAME="plugins/TimeManagementReminder.xml">
<Parameters REMINDUSERAT="1666036948349"/>
</hook>
<attribute NAME="Marc" VALUE="R&#xe9;aliser l&apos;analyse des besoins."/>
</node>
</node>
<node CREATED="1666035490175" ID="ID_1470312372" MODIFIED="1666035512524" TEXT="Mener."/>
<node CREATED="1666035493714" ID="ID_1018235350" MODIFIED="1666035518487" TEXT="&#xc9;valuer."/>
</node>
<node COLOR="#009900" CREATED="1666034500124" ID="ID_467958295" MODIFIED="1666034894879" POSITION="right" TEXT="Documents et Liens.">
<icon BUILTIN="folder"/>
<node CREATED="1666034918766" ID="ID_929105494" LINK="../Liste%20d&apos;exp&#xe9;riences%20personnelles%20obtenues%20lors%20de%20la%20r&#xe9;alisation%20de%20plusieurs%20activit&#xe9;s%20de%20toute%20nature,%20au%20cours%20de%20ma%20vie%20personnelle%20-%20Liste%20de%20mes%20Comp&#xe9;tences%20Personnelles%20-%20INF%204018.docx" MODIFIED="1666035426359" TEXT="Documents."/>
<node CREATED="1666034928425" ID="ID_752111268" MODIFIED="1666034942378" TEXT="Liens_Internet.">
<node CREATED="1666035098894" ID="ID_1234955041" LINK="http://benhur.teluq.uquebec.ca/SPIP/inf4018/" MODIFIED="1666035098894" TEXT="benhur.teluq.uquebec.ca &gt; SPIP &gt; Inf4018"/>
</node>
</node>
</node>
</map>
